import os, random
import pandas as pd
from datetime import date, timedelta

random.seed(42)
os.makedirs("data",exist_ok=True)

# Synthetic Hyderabad-like coordinate range for demonstration only.
centers=[
    (17.3850,78.4867),(17.4065,78.4772),(17.4156,78.4347),
    (17.3616,78.4747),(17.4435,78.3772),(17.4948,78.3996),
    (17.4500,78.5600),(17.3300,78.5800)
]
types=["Theft","Burglary","Traffic Incident","Property Damage","Fraud","Assault"]
rows=[]
start=date(2025,1,1)
for i in range(1800):
    d=start+timedelta(days=random.randint(0,364))
    c=random.choice(centers)
    lat=c[0]+random.gauss(0,.012)
    lon=c[1]+random.gauss(0,.012)
    hour=random.randrange(24)
    # Synthetic pattern only: no real-world claim.
    base=1.2
    if 18<=hour<=23: base+=1.6
    if 0<=hour<=3: base+=1.0
    if d.weekday()>=5: base+=.5
    rain=random.random()*18 if random.random()<.3 else 0
    temp=23+random.random()*13
    count=max(0, round(random.gauss(base+rain*.015,.9)))
    rows.append([d.isoformat(),round(lat,6),round(lon,6),hour,
                 random.choice(types),count,round(temp,1),round(rain,1)])
df=pd.DataFrame(rows,columns=["date","latitude","longitude","hour","crime_type","crime_count","temperature","rainfall"])
df.to_csv("data/crime_data.csv",index=False)
print("Created data/crime_data.csv with",len(df),"synthetic records.")
