from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import os, json

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data", "crime_data.csv")

def load_data():
    df = pd.read_csv(DATA)
    df["date"] = pd.to_datetime(df["date"])
    df["day_of_week"] = df["date"].dt.dayofweek
    df["month"] = df["date"].dt.month
    return df

def train_model(df):
    features = ["latitude","longitude","hour","day_of_week","month","temperature","rainfall"]
    X=df[features]
    y=df["crime_count"]
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,random_state=42)
    model=RandomForestRegressor(n_estimators=250,max_depth=14,random_state=42,n_jobs=-1)
    model.fit(X_train,y_train)
    pred=model.predict(X_test)
    return model, {
        "mae": round(float(mean_absolute_error(y_test,pred)),2),
        "r2": round(float(r2_score(y_test,pred)),3)
    }

def build_hotspots(df, k=8):
    coords=df[["latitude","longitude"]].copy()
    model=KMeans(n_clusters=k,random_state=42,n_init=10)
    df=df.copy()
    df["cluster"]=model.fit_predict(coords)
    summary=df.groupby("cluster").agg(
        latitude=("latitude","mean"),
        longitude=("longitude","mean"),
        incidents=("crime_count","sum"),
        records=("crime_count","count")
    ).reset_index()
    summary["risk_index"]=(summary["incidents"]/summary["incidents"].max()*100).round(1)
    summary["risk_level"]=pd.cut(
        summary["risk_index"], bins=[-1,33,66,101],
        labels=["Low","Medium","High"]
    ).astype(str)
    return summary.sort_values("risk_index",ascending=False)

df=load_data()
model, metrics=train_model(df)
hotspots=build_hotspots(df)

@app.route("/")
def index():
    return render_template("index.html", metrics=metrics, total=len(df),
                           incidents=int(df["crime_count"].sum()),
                           hotspots=hotspots.to_dict("records"))

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html", metrics=metrics, total=len(df),
                           incidents=int(df["crime_count"].sum()),
                           hotspots=hotspots.to_dict("records"))

@app.route("/api/hotspots")
def api_hotspots():
    return jsonify(hotspots.to_dict("records"))

@app.route("/api/predict", methods=["POST"])
def predict():
    data=request.get_json(force=True)
    required=["latitude","longitude","hour","day_of_week","month","temperature","rainfall"]
    try:
        values=[float(data[x]) for x in required]
        X=pd.DataFrame([values],columns=required)
        prediction=float(model.predict(X)[0])
        return jsonify({
            "predicted_incidents":round(max(prediction,0),2),
            "interpretation":"Model-estimated incident count for the supplied conditions."
        })
    except Exception as e:
        return jsonify({"error":str(e)}),400

@app.route("/api/chart")
def chart():
    hourly=df.groupby("hour")["crime_count"].sum().reindex(range(24),fill_value=0)
    dow=df.groupby("day_of_week")["crime_count"].sum().reindex(range(7),fill_value=0)
    return jsonify({
        "hours":list(range(24)),
        "hour_counts":hourly.astype(int).tolist(),
        "days":["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
        "day_counts":dow.astype(int).tolist()
    })

if __name__=="__main__":
    app.run(debug=True)
