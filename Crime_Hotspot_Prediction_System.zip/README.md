# Crime Hotspot Prediction System

A complete academic ML web application built with Python, Flask, Pandas,
Scikit-learn and a browser dashboard.

## Important project scope
This is an educational analytics prototype. The included CSV is synthetic
demonstration data. It should not be used to make decisions about individuals,
deploy police resources, or infer that a person or neighborhood is inherently
criminal. Real deployments require domain review, representative data,
fairness testing, privacy safeguards and validation.

## Features
1. Crime dataset dashboard
2. Random Forest regression for estimated incident count
3. K-Means spatial hotspot clustering
4. Interactive hotspot map using Leaflet
5. Hour/day crime-pattern charts
6. Prediction form
7. Model metrics (MAE and R²)
8. REST API endpoints
9. Synthetic dataset generator included
10. Responsive UI

## Run on Windows

Open the folder in VS Code.

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open:
http://127.0.0.1:5000

## Run on Linux/macOS

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Dataset
`data/crime_data.csv` contains synthetic records with:
- date
- latitude
- longitude
- hour
- crime_type
- crime_count
- temperature
- rainfall

Replace the dataset only after checking column names and data quality.

## ML pipeline

### Hotspot detection
K-Means clusters latitude/longitude coordinates. Cluster incident totals
are normalized to a relative hotspot index for visualization.

### Incident estimation
RandomForestRegressor uses:
latitude, longitude, hour, day_of_week, month, temperature, rainfall

Target:
crime_count

This is a regression demonstration, not a claim of certainty about future crime.

## API

GET:
`/api/hotspots`

GET:
`/api/chart`

POST:
`/api/predict`

Example JSON:
```json
{
  "latitude":17.405,
  "longitude":78.485,
  "hour":21,
  "day_of_week":5,
  "month":9,
  "temperature":28,
  "rainfall":2
}
```

## Suggested extensions
- PostgreSQL/MySQL
- user authentication
- admin dashboard
- real-time data ingestion
- temporal models
- explainable AI with SHAP
- model monitoring
- fairness and privacy audit
- downloadable reports
